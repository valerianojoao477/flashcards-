criaCartao(
    'Veículos',
    'Qual é a função do catalisador em um automóvel?',
    'Reduz gases poluentes do escapamento'
)

criaCartao(
    'Artistas',
    'Quem pintou a obra "Guernica"?',
    'Pablo Picasso'
)

criaCartao(
    'Esportes',
    'Qual país venceu a Copa do Mundo de 2018?',
    'França'
)

criaCartao(
    'Biologia',
    'Qual é a molécula responsável por carregar o código genético?',
    'DNA'
)
criaCartao(
    'Veículos',
    'O que significa a sigla "ABS" nos sistemas de freio?',
    'Sistema de frios antitravamento'
)

criaCartao(
    'Artistas',
    'Qual artista ficou conhecido por cortar sua própria orelha?',
    'Vicent Van Gogh'
)

criaCartao(
    'Esportes',
    'Quantos jogadores há em um time de vôlei?',
    'Seis'
)
criaCartao(
    'Biologia',
    'O que são mitocôndrias e qual sua função na célula?',
    'Organelas que produzem energia (ATP)'
)

criaCartao(
    'Veículos',
    'Qual a diferença entre motor a gasolina e motor diesel?',
    'Gasolina usa combustão por faísca e diesel por compressão'
)

criaCartao(
    'Artistas',
    'Que cantor brasileiro é conhecido como o "Rei" da música romântica?',
    'Roberto Carlos'
)

criaCartao(
    'Esportes',
    'Qual é o nome da competição internacional mais importante do atletismo?',
    'Campeonato Mundial de Atletismo'
)
    criaCartao(
    'Biologia',
    'O que diferencia um ser vivo autotrófico de um heterotrófico?',
    'Autotróficos produzem seu própio alimento, heterotróficos não'
)

criaCartao(
    'Veículos',
    'O que caracteriza um carro elétrico?',
    'Movido apenas por motor elétrico e baterias'
)

criaCartao(
    'Artistas',
    'Qual o nome verdadeiro da Lady Gaga?',
    'Stefani Joanne Angelina Germanotta'
)

criaCartao(
    'Esportes',
    'Em que esporte se destacaram Michael Jordan e LeBron James?',
    'Basquete'
)
criaCartao(
    'Onde ocorre a fotossíntese nas plantas?',
    'Como se diz oi em Inglês?',
    'Nos cloroplastos )'
)
